import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'angular-src';
  // app.component.html 에 있는 span > {{ title }} 부분에 들어갈 내용
}
